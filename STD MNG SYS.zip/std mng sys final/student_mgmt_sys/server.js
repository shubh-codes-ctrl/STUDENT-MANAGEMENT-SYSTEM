const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const multer = require('multer');

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'public/uploads/');
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname);
    }
});

const upload = multer({ storage: storage });

const app = express();
const port = 8000;

// Database connection
const db = new sqlite3.Database('student_management.db', (err) => {
  if (err) {
    console.error(err.message);
    throw err;
  }
  console.log('Connected to SQLite database');
  // Enable foreign key constraints
  db.run('PRAGMA foreign_keys = ON');
});

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: 'secret',
  resave: true,
  saveUninitialized: true
}));

// Set view engine
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Routes
app.get('/', (req, res) => {
  res.render('login');
});

app.post('/auth', (req, res) => {
  const { username, password } = req.body;
  // For demo purposes, we'll keep the hardcoded admin login
  // In production, you would query the database:
  /*
  db.get('SELECT * FROM users WHERE username = ? AND password = ?', 
    [username, password], (err, row) => {
      if (err) {
        console.error(err);
        return res.status(500).send('Database error');
      }
      if (row) {
        req.session.loggedin = true;
        req.session.username = row.username;
        res.redirect('/dashboard');
      } else {
        res.send('Incorrect username and/or password!');
      }
    });
  */
  if (username === 'admin' && password === 'admin123') {
    req.session.loggedin = true;
    req.session.username = username;
    res.redirect('/dashboard');
  } else {
    res.send('Incorrect username and/or password!');
  }
});

app.get('/dashboard', (req, res) => {
  if (req.session.loggedin) {
    res.render('dashboard', { username: req.session.username });
  } else {
    res.redirect('/');
  }
});

app.get('/home', (req, res) => {
  if (req.session.loggedin) {
    res.render('home', { username: req.session.username });
  } else {
    res.redirect('/');
  }
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

// Add Student routes
app.get('/add-student', (req, res) => {
  if (req.session.loggedin) {
    db.all("SELECT id, name FROM courses", [], (err, rows) => {
      if (err) {
          console.error("Database error:", err);
          return res.status(500).send("Database error");
      }
      console.log("Courses fetched successfully:", rows);  
      res.render('add-student', { username: req.session.username, courses: rows });
      });
  } else {
      res.redirect('/');
  }
});
// Students List route
app.get('/students-list', (req, res) => {
  if (req.session.loggedin) {
    // Get students with their course and fees information
    const query = `
      SELECT s.*, c.name AS course_name, 
             (SELECT status FROM fees f 
              JOIN enrollments e ON f.enrollment_id = e.id 
              WHERE e.student_id = s.id ORDER BY f.id DESC LIMIT 1) AS fees_status,
             (SELECT ROUND((SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) * 100.0 / COUNT(*)), 1) 
              FROM attendance a 
              JOIN enrollments e ON a.enrollment_id = e.id 
              WHERE e.student_id = s.id) AS attendance_percentage
      FROM students s
      LEFT JOIN courses c ON s.course_id = c.id
    `;
    
    // Get courses for filter dropdown
    db.all('SELECT * FROM courses', (err, courses) => { // Use db.all instead of db.query
      if (err) throw err;
      
      db.all(query, (err, students) => { // Use db.all instead of db.query
        if (err) throw err;
        
        res.render('students-list-new', {
          username: req.session.username,
          students: students,
          courses: courses
        });
      });
    });
  } else {
    res.redirect('/');
  }
});

// Courses Management Routes
app.get('/courses', (req, res) => {
  db.all("SELECT id, name, duration, fees FROM courses", [], (err, rows) => {
      if (err) {
          console.error("Error fetching courses:", err.message); // Log detailed error
          return res.status(500).send("Database error: " + err.message);
      }
      console.log("Courses fetched successfully:", rows);
      res.render('courses', { courses: rows, username: "Admin" });
  });
});
app.post('/add-course', (req, res) => {
  if (req.session.loggedin) {
      const { name, duration, fees } = req.body;

      // Validate input
      if (!name || !duration || !fees) {
          return res.status(400).send('All fields are required.');
      }

      db.run('INSERT INTO courses (name, duration, fees) VALUES (?, ?, ?)', 
          [name, duration, fees], 
          function(err) {
              if (err) {
                  console.error('Error adding course:', err.message);
                  return res.status(500).send('Error adding course');
              }
              res.redirect('/courses');
          }
      );
  } else {
      res.redirect('/'); // Redirect to login if not logged in
  }
});
app.post('/edit-course', (req, res) => {
if (req.session.loggedin) {
  const { id, name, duration, fees } = req.body;
  const courseData = { name, duration, fees };

  db.run('UPDATE courses SET name = ?, duration = ?, fees = ? WHERE id = ?', 
    [name, duration, fees, id], 
    function(err) {
      if (err) {
        console.error(err);
        return res.status(500).send('Error updating course');
      }
      res.redirect('/courses');
    }
  );
} else {
  res.redirect('/');
}
});

app.get('/delete-course/:id', (req, res) => {
if (req.session.loggedin) {
  const courseId = req.params.id;

  db.run('DELETE FROM courses WHERE id = ?', [courseId], function(err) {
    if (err) {
      console.error(err);
      return res.status(500).send('Error deleting course');
    }
    res.redirect('/courses');
  });
} else {
  res.redirect('/');
}
});
// Enrollment routes
app.get('/enrollment', (req, res) => {
  if (req.session.loggedin) {
    // Get enrollments with student and course info
    const query = `
      SELECT e.id, e.enrollment_date, 
             s.full_name AS student_name, s.profile_photo,
             c.name AS course_name
      FROM enrollments e
      JOIN students s ON e.student_id = s.id
      JOIN courses c ON e.course_id = c.id
    `;
    
    // Get students and courses for dropdowns
    db.all('SELECT id, full_name, roll_number FROM students', (err, students) => {
      if (err) {
        console.error(err);
        return res.status(500).send('Database error');
      }
      
      db.all('SELECT id, name, fees FROM courses', (err, courses) => {
        if (err) {
          console.error(err);
          return res.status(500).send('Database error');
        }
        
        db.all(query, (err, enrollments) => {
          if (err) {
            console.error(err);
            return res.status(500).send('Database error');
          }
          
          res.render('enrollment', {
            username: req.session.username,
            students: students,
            courses: courses,
            enrollments: enrollments
          });
        });
      });
    });
  } else {
    res.redirect('/');
  }
});

app.post('/enroll-student', (req, res) => {
  if (req.session.loggedin) {
    const { student_id, course_id, enrollment_date } = req.body;
    const enrollmentData = { student_id, course_id, enrollment_date };

    db.run('INSERT INTO enrollments (student_id, course_id, enrollment_date) VALUES (?, ?, ?)', 
      [enrollmentData.student_id, enrollmentData.course_id, enrollmentData.enrollment_date],
      function(err) {
        if (err) {
          console.error(err);
          return res.status(500).send('Error enrolling student');
        }
        res.redirect('/enrollment');
      }
    );
  } else {
    res.redirect('/');
  }
});

app.get('/remove-enrollment/:id', (req, res) => {
  if (req.session.loggedin) {
    const enrollmentId = req.params.id;

    db.run('DELETE FROM enrollments WHERE id = ?', [enrollmentId], function(err) {
      if (err) {
        console.error(err);
        return res.status(500).send('Error removing enrollment');
      }
      res.redirect('/enrollment');
    });
  } else {
    res.redirect('/');
  }
});

// Fees Management routes
app.get('/fees-management', (req, res) => {
  if (req.session.loggedin) {
    // Get fees with student and course info
    const query = `
      SELECT f.id, f.amount, f.payment_date, f.status,
             s.full_name AS student_name, s.profile_photo,
             c.name AS course_name
      FROM fees f
      JOIN enrollments e ON f.enrollment_id = e.id
      JOIN students s ON e.student_id = s.id
      JOIN courses c ON e.course_id = c.id
    `;
    
    // Get students for dropdown
    db.all('SELECT id, full_name, roll_number FROM students', (err, students) => {
      if (err) {
        console.error(err);
        return res.status(500).send('Database error');
      }
      
      db.all(query, (err, fees) => {
        if (err) {
          console.error(err);
          return res.status(500).send('Database error');
        }
        
        res.render('fees-management', {
          username: req.session.username,
          students: students,
          fees: fees
        });
      });
    });
  } else {
    res.redirect('/');
  }
});

app.post('/record-payment', (req, res) => {
  if (req.session.loggedin) {
    const { student_id, amount, payment_date, status } = req.body;
    
    // First get the enrollment_id for this student
    db.get('SELECT id FROM enrollments WHERE student_id = ?', [student_id], (err, enrollment) => {
      if (err) {
        console.error(err);
        return res.status(500).send('Error finding enrollment');
      }
      
      if (!enrollment) {
        return res.status(400).send('Student is not enrolled in any course');
      }
      
      db.run('INSERT INTO fees (enrollment_id, amount, payment_date, status) VALUES (?, ?, ?, ?)', 
        [enrollment.id, amount, payment_date, status],
        function(err) {
          if (err) {
            console.error(err);
            return res.status(500).send('Error recording payment');
          }
          res.redirect('/fees-management');
        }
      );
    });
  } else {
    res.redirect('/');
  }
});

app.get('/print-receipt/:id', (req, res) => {
  if (req.session.loggedin) {
    const paymentId = req.params.id;
    
    // Get payment details with student and course info
    const query = `
      SELECT f.*, s.full_name AS student_name, s.roll_number,
             c.name AS course_name, c.fees AS course_fees
      FROM fees f
      JOIN enrollments e ON f.enrollment_id = e.id
      JOIN students s ON e.student_id = s.id
      JOIN courses c ON e.course_id = c.id
      WHERE f.id = ?
    `;
    
    db.get(query, [paymentId], (err, payment) => {
      if (err) {
        console.error(err);
        return res.status(500).send('Error generating receipt');
      }
      
      if (!payment) {
        return res.status(404).send('Payment not found');
      }
      res.render('receipt', { payment });
    });
  } else {
    res.redirect('/');
  }
});

// Attendance routes
app.get('/attendance', (req, res) => {
  if (req.session.loggedin) {
    // Get attendance records with student and course info
    const query = `
      SELECT a.id, a.date, a.status,
             s.full_name AS student_name, s.profile_photo,
             c.name AS course_name
      FROM attendance a
      JOIN enrollments e ON a.enrollment_id = e.id
      JOIN students s ON e.student_id = s.id
      JOIN courses c ON e.course_id = c.id
      ORDER BY a.date DESC
    `;
    
    // Get students for dropdown
    db.all('SELECT id, full_name, roll_number FROM students', (err, students) => {
      if (err) {
        console.error(err);
        return res.status(500).send('Database error');
      }
      
      db.all(query, (err, attendanceRecords) => {
        if (err) {
          console.error(err);
          return res.status(500).send('Database error');
        }
        
        res.render('attendance', {
          username: req.session.username,
          students: students,
          attendanceRecords: attendanceRecords
        });
      });
    });
  } else {
    res.redirect('/');
  }
});

app.post('/mark-attendance', (req, res) => {
  if (req.session.loggedin) {
    const { student_id, date, status } = req.body;
    
    // First get the enrollment_id for this student
    db.get('SELECT id FROM enrollments WHERE student_id = ?', [student_id], (err, enrollment) => {
      if (err) {
        console.error(err);
        return res.status(500).send('Error finding enrollment');
      }
      
      if (!enrollment) {
        return res.status(400).send('Student is not enrolled in any course');
      }
      
      const attendanceData = { 
        enrollment_id: enrollment.id,
        date,
        status
      };

      db.run('INSERT INTO attendance (enrollment_id, date, status) VALUES (?, ?, ?)', 
        [attendanceData.enrollment_id, attendanceData.date, attendanceData.status],
        function(err) {
          if (err) {
            console.error(err);
            return res.status(500).send('Error recording attendance');
          }
          res.redirect('/attendance');
        }
      );
    });
  } else {
    res.redirect('/');
  }
});
app.post('/add-student', upload.single('profile_photo'), (req, res) => {
  if (req.session.loggedin) {
      const { 
          full_name,
          roll_number,
          date_of_birth,
          gender,
          address,
          parent_name,
          contact_number,
          email,
          course // This should be the course ID
      } = req.body;

      // Check if course is selected
      if (!course) {
          return res.status(400).send('Course must be selected.');
      }

      // Handle profile photo upload
      const profile_photo = req.file ? '/uploads/' + req.file.filename : null;

      // Prepare student data for insertion
      const studentData = {
          full_name,
          roll_number,
          date_of_birth,
          gender,
          address,
          parent_name,
          contact_number,
          email,
          profile_photo,
          course_id: course // This should be the course ID
      };

      console.log('Inserting student with data:', studentData); // Log the data being inserted

      // Insert student into database
      const columns = ['full_name', 'roll_number', 'date_of_birth', 'gender', 'address', 
                      'parent_name', 'contact_number', 'email', 'profile_photo', 'course_id'];
      const values = columns.map(col => studentData[col]);

      db.run(`INSERT INTO students (${columns.join(', ')}) VALUES (${columns.map(() => '?').join(', ')})`, 
          values,
          function(err) {
              if (err) {
                  console.error('Error adding student:', err.message);
                  return res.status(500).send('Error adding student');
              }
              res.redirect('/students-list');
          }
      );
  } else {
      res.redirect('/'); // Redirect to login if not logged in
  }
});

// Start server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});